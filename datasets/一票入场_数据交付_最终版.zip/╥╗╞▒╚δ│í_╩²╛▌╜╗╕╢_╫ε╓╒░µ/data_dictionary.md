# 数据字典：《一票入场》网站完整数据

> **版本**: V1.0 · **日期**: 2026-08-02 · **负责人**: 数据负责人2

---

## 文件总览

| 文件 | 说明 | 记录数 |
|---|---|---|
| `relations.json` | 戏单与实体之间的关联关系表 | 1,537 条 |
| `entities.json` | 关联实体的详细信息（百科数据） | 652 个唯一实体 |
| `tickets_detail.json` | 834 张戏单的完整结构化数据（API 原始返回） | 834 张 |
| `images.json` | 实体图片 URL 索引 | 313 个实体有图 |

---

## 一、relations.json —— 关联关系表

**来源**: 《一票入场_834条最终关联审核结果_20260727.xlsx》→ `02_网站导入关系`

**用途**: 网站加载后，根据戏单 `nid` 查出该戏单关联了哪些人物、机构、剧院等实体。

### 字段定义

| 字段 | 类型 | 必填 | 说明 | 示例 |
|---|---|---|---|---|
| `relation_id` | string | ✅ | 关联关系唯一标识，格式 `REL-XXXXX` | `"REL-00001"` |
| `nid` | integer | ✅ | 关联的戏单唯一编号（外键） | `1721` |
| `ticket_title` | string | ✅ | 戏单题名 | `"圣母院"` |
| `entity_name` | string | ✅ | 实体名称（可能含上图标注如 `@chs`） | `"上海京剧院@chs"` |
| `entity_type` | string | ✅ | 实体类型（见下方枚举） | `"person"` |
| `entity_uri` | string | ✅ | 实体在上图开放数据平台中的 URI | `"http://data.library.sh.cn/entity/person/u0veq6s7dbzf6kfx"` |
| `relation_types` | string | ✅ | 关联类型描述 | `"戏单详情直接关联"` |
| `mention_texts` | string | ✅ | 在戏单原始数据中出现的文本 | `"单跃进"` |
| `source_fields` | string | ✅ | 线索来源字段路径 | `"PerformanceWork[0].work_other_performer"` |
| `dataset_name` | string | ✅ | 上图数据集名称 | `"上海图书馆戏单开放数据"` |
| `evidence_level` | string | ✅ | 证据等级：`A` = 直接URI关联，`B` = 高置信度推断 | `"A"` |
| `review_status` | string | ✅ | 人工审核状态（全部为 `"已核验"`） | `"已核验"` |
| `evidence_text` | string | ✅ | 证据说明文本 | `"PerformanceWork[0].work_other_performer直接返回workuri"` |

### entity_type 枚举

| 值 | 含义 | 数量 | 对应 API 端点 |
|---|---|---|---|
| `person` | 人物（演员、编剧、导演等） | 1,236 | `/shnh/wkl/webapi/persons/detail` |
| `organization` | 机构（演出单位、主办方等） | 252 | `/shnh/whzk/webapi/org/detail` |
| `theater` | 剧院/演出场馆 | 47 | `/shnh/dydata/webapi/architecture/architectureDetail` |
| `event` | 历史事件 | 1 | `/webapi/hsly/route/getEventDetail` |
| `architecture` | 建筑/地标 | 1 | `/shnh/gmwx/webapi/architecture/getArchitectureDetail` |

### relation_types 分布

| 关联类型 | 数量 | 说明 |
|---|---|---|
| 戏单详情直接关联 | 1,127 | 戏单 API 直接返回了该实体的 URI |
| organization→organization | 252 | 通过名称在机构名录中匹配 |
| venue→theater | 47 | 通过场馆名称匹配到剧院实体 |
| person→person | 83 | 通过演员名称在人物知识库中匹配 |
| 舞台角色/所饰人物→人物实体 | 26 | 剧中角色对应历史人物 |
| event→event | 1 | 事件匹配 |
| place→architecture | 1 | 地名匹配建筑 |

---

## 二、entities.json —— 实体详情库

**来源**: 通过上海图书馆 API 从 `relations.json` 中的 652 个唯一 `entity_uri` 实时拉取。

**用途**: 在前端展示关联实体的详细信息——人物卡片、机构介绍、剧院历史沿革和地址坐标。

### 顶层结构（所有类型通用）

| 字段 | 类型 | 说明 |
|---|---|---|
| `entity_uri` | string | 实体 URI（主键，可直接用于索引） |
| `entity_type` | string | 实体类型 |
| `entity_name` | string | 原始名称（可能含 `@chs` 等后缀） |
| `clean_name` | string | 清理后的显示名称（已去除 `@chs` / `@en`） |
| `related_nids` | array[int] | 关联到哪些戏单的 nid |
| `api_success` | bool | API 调用是否成功 |
| `api_endpoint` | string | 使用的 API 端点 |
| `api_data` | object | API 返回的原始数据 |
| `api_error` | string\|null | 失败时的错误信息 |

### 人物 (person) — api_data 字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `chs_name` | string | 中文简体名 |
| `cht_name` | string | 中文繁体名 |
| `en_name` | string | 英文/拼音名 |
| `noteOfSource` | string | 数据来源（如"国图规范档"） |
| `briefBiography` | array[string] | 简要生平 |
| `relatedOrganization` | array[string] | 关联机构名称列表 |
| `uri` | string | 实体 URI |
| `hasFile` | string | 是否有照片文件（`"0"` 或 `"1"`） |
| `img` | string | 人物照片 URL（如存在） |

### 机构 (organization) — api_data.data 字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `name` | array[string] | 多语种名称（含 `@chs` / `@en` / `@cht` 后缀） |
| `description` | array[string] | 机构简介 |
| `created` | string | 成立日期 |
| `noteOfSource` | string | 数据来源 |
| `type` | string | 机构类型 |
| `uri` | string | 实体 URI |

### 剧院 (theater) — api_data.data[0].architecture 字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `nameS` / `nameT` / `nameE` | string | 中/繁/英文名 |
| `des` | string | 历史沿革简介 |
| `address` | string | 地址（在 building 子对象中） |
| `lon` / `lat` | string | 经纬度（在 building 子对象中） |
| `imagesList` | array | 历史照片列表 |
| `imagesList[].imgP` | string | 图片 URL（直接 JPG 链接） |
| `imagesList[].imageUri` | string | 图片 URI |
| `imagesList[].description` | string | 图片说明文字 |
| `imagesList[].source` | string | 图片来源 |
| `eventList` | array | 历史事件时间线 |
| `personList` | array | 关联人物 |
| `dramaName` | string | 在此上演过的剧目列表 |

### 事件 (event) — api_data.data[0] 字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `title` | string | 事件标题 |
| `description` | string | 事件描述 |
| `dateLabel` | string | 事件日期 |
| `begin` / `end` | string | 开始/结束日期 |
| `personList` / `organizationList` / `placeList` | array | 关联的人物/机构/地点 |
| `imageList` | array | 事件图片（当前为空） |

---

## 三、tickets_detail.json —— 戏单完整结构化数据

**来源**: 通过上图 API `/webapi/xd/detail?nid=...` 拉取 834 张戏单。

**用途**: 
1. 戏单详情页的结构化数据源
2. 获取原图中的演员 URI（A 级关联的来源）
3. 与数据负责人1 的 `tickets.json` 互为验证

### 顶层结构

```json
{
  "<nid>": {
    "success": true,
    "nid": 1721,
    "data": { "status": "success", "data": [ { "Event": {...}, "PerformanceWork": [...] } ] }
  }
}
```

### Event（事件/演出）字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `event_name` | array[string] | 演出名称 |
| `event_year` | array[string] | 年份 |
| `event_place` | array[string] | 地点 |
| `performance_type` | array[string] | 演出类型（如"演奏""话剧""京剧"） |
| `performance_event_des` | array[string] | 演出描述 |
| `performance_time` | array[object] | 演出时间 |
| `performance_time[].performance_start_time` | string | 开始日期（`YYYYMMDD`） |
| `performance_time[].performance_end_time` | string | 结束日期（`YYYYMMDD`） |
| `performance_time[].performance_time_des` | string | 时间文本描述 |
| `performance_place` | object | 演出场馆 |
| `performance_place.performance_place_name` | string | 场馆名称 |
| `performance_place.performance_address` | string | 场馆地址 |
| `performance_place.performance_place_type` | string | 场馆类型（如"剧场"） |
| `agent_performance_unit` | array[object] | 演出单位 |
| `agent_performer` | array[object] | 参演人员 |

### PerformanceWork（剧目）字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `work_name` | string | 剧目名称 |
| `work_drama_type` | array[string] | 剧种 |
| `synopsis_info` | string | 剧情梗概 |
| `work_remark` | string | 备注说明 |
| `pre_adapt_work` | object | 改编来源信息 |
| `work_performer` | array[object] | 演员列表 |
| `work_performer[].work_performer_name` | string | 演员姓名 |
| `work_performer[].work_performer_role` | string | 饰演角色 |
| `work_performer[].work_performer_des` | string | 演员简介 |
| `work_performer[].workuri` | string | 演员 URI（A 级关联的来源） |
| `work_other_performer` | array[object] | 其他参与者（编剧、导演等） |

---

## 四、images.json —— 实体图片索引

**来源**: 从 `entities.json` 的 `api_data` 中提取所有图片 URL。

**用途**: 网站直接按 `entity_uri` 查图，无需遍历庞大的 `entities.json`。

### 结构

```json
{
  "person": {
    "<entity_uri>": {
      "name": "石玉昆",
      "image_url": "https://img.library.sh.cn/person/krq6wuwc28ykr9kp.jpg"
    }
  },
  "theater": {
    "<entity_uri>": {
      "name": "兰心大戏院",
      "images": [
        { "url": "https://img.library.sh.cn/shmemory/architecture/img/xxx.jpg",
          "description": "图为复名后的兰心大戏院" }
      ]
    }
  }
}
```

### 图片统计

| 实体类型 | 有图片的实体数 | 图片总数 | URL 格式 |
|---|---|---|---|
| person | 309 | 309 | `https://img.library.sh.cn/person/{id}.jpg` |
| theater | 4 | 68 | `https://img.library.sh.cn/shmemory/architecture/img/{hash}.jpg` |
| organization | 0 | 0 | — |
| event | 0 | 0 | — |
| architecture | 0 | 0 | — |

### 图片覆盖的关联关系

- 有图的关联: 681 / 1,537 条（44.3%）
- 无图的关联: 856 / 1,537 条（55.7%）
- 无图时前端应展示文字首字母头像或占位图

---

## 五、文件间关联关系

```
                    ┌── nid ──► tickets_detail.json[<nid>]
                    │              └── 戏单完整数据（演员表、剧目、时间地点）
                    │
relations.json ─────┤
 (1537条)           │         ┌── entities.json[<entity_uri>]
                    │         │     └── 实体百科详情（生卒、简介、经纬度等）
                    └── entity_uri ──┤
                              │     └── images.json["person"][<entity_uri>]
                              │           └── 人物照片 URL
                              │
                              └── images.json["theater"][<entity_uri>]
                                    └── 剧院历史照片列表
```

**查询路径示例**（以戏单 1721 "圣母院" 为例）:

1. 前端加载 `tickets_detail.json["1721"]` → 拿到演出名、时间、地点、演员表
2. 前端查 `relations` 中 `nid == 1721` → 得到 4 条关联（单跃进、杨乃林、石玉昆、上海京剧院）
3. 对每条关联拿 `entity_uri` → 查 `entities.json[uri]` 拿到详细信息
4. 对人物，再查 `images.json["person"][entity_uri]` → 如果有，展示照片
