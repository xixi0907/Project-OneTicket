# 《一票入场》—— 数据负责人2 交付物完整说明

> **版本**: V1.0 · **日期**: 2026-08-02 · **目标**: 为网站组提供可直接导入的完整关联数据和实体详情

---

## 一、交付物清单

本目录共 4 个数据文件 + 2 份文档，所有数据已清洗、验证，可直接用于网站搭建。

### 数据文件（给网站组）

| 文件 | 大小 | 内容 | 网站用途 |
|---|---|---|---|
| **`relations.json`** | 1.3 MB | 1,537 条已核验关联关系 | 网站的核心关联表，根据 nid 查出关联的人物/机构/剧院 |
| **`entities.json`** | 1.4 MB | 652 个实体的百科详情 | 展示人物卡片、机构介绍、剧院历史沿革 |
| **`tickets_detail.json`** | 8.5 MB | 834 张戏单的完整结构化数据 | 戏单详情页数据源（演员表、剧目、时间地点、剧情梗概） |
| **`images.json`** | 69 KB | 313 个实体的图片 URL | 展示人物照片、剧院历史照片 |

### 文档

| 文件 | 内容 |
|---|---|
| **`data_dictionary.md`** | 每个文件的完整字段定义、类型枚举、取值说明 |
| **`data_check.md`** | 数据质检报告（全部通过）、验收标准对照表 |

---

## 二、每个文件是干什么的

### 2.1 relations.json —— 关联关系表（核心）

**一句话**: 告诉你"哪张戏单关联了哪个人物/机构/剧院"。

**结构**: 一个数组，每条记录包含 13 个字段：

```json
{
  "relation_id": "REL-00001",
  "nid": 1721,
  "ticket_title": "圣母院",
  "entity_name": "单跃进",
  "entity_type": "person",
  "entity_uri": "http://data.library.sh.cn/entity/person/u0veq6s7dbzf6kfx",
  "relation_types": "戏单详情直接关联",
  "evidence_level": "A",
  "review_status": "已核验"
}
```

**关键数字**:
- 1,537 条关系 · 覆盖 561 张戏单（67.3%）
- 1,192 条 A 级（直接 URI 关联，高可信）· 345 条 B 级（推断关联，经人工核验）
- 273 张戏单无关联（详情页需显示"暂未检出可确认关联"）

**前端怎么用**: 页面加载时把整个文件 fetch 进来，根据当前戏单 nid 筛选对应的关联，再按 entity_type 分组展示。

---

### 2.2 entities.json —— 实体百科详情

**一句话**: "单跃进"到底是谁？这个文件有他的生卒年、关联机构、小传。

**结构**: 一个字典，key 是 `entity_uri`，value 是实体详情。

```json
{
  "http://data.library.sh.cn/entity/person/u0veq6s7dbzf6kfx": {
    "entity_type": "person",
    "clean_name": "单跃进",
    "api_data": {
      "data": {
        "chs_name": "单跃进",
        "en_name": "shan yue jin",
        "relatedOrganization": ["上海京剧院", "戏曲剧目制"],
        "noteOfSource": "国图规范档"
      }
    }
  }
}
```

**不同实体类型的详情字段**:

| 类型 | 典型字段 |
|---|---|
| person | `chs_name`, `en_name`, `relatedOrganization`, `briefBiography` |
| organization | `name[]`, `description[]`, `created`, `type` |
| theater | `nameS/E/T`, `des`（历史沿革）, `address`, `lon/lat`（经纬度）, `imagesList`, `eventList` |

**关键数字**: 652 个唯一实体 · 651/652 API 调用成功 · 仅 1 个失败（白云明）

---

### 2.3 tickets_detail.json —— 戏单完整原始数据

**一句话**: 每张戏单在上图数据库里的全部信息——谁演的、演什么、什么时候、在哪儿。

**结构**: 字典，key 为 nid 字符串。

```json
{
  "1721": {
    "success": true,
    "nid": 1721,
    "data": {
      "data": [{
        "Event": {
          "event_name": ["圣母院"],
          "event_year": ["2008年"],
          "performance_time": [{
            "performance_start_time": "20080514",
            "performance_end_time": "20080515"
          }],
          "performance_place": {
            "performance_place_name": "上海天蟾逸夫舞台"
          }
        },
        "PerformanceWork": [{
          "work_name": "圣母院",
          "work_drama_type": ["京剧"],
          "synopsis_info": "根据维克多·雨果小说《巴黎圣母院》改编...",
          "work_performer": [{
            "work_performer_name": "史依弘",
            "work_performer_role": "艾丽雅",
            "work_performer_des": "上海京剧院国家一级演员..."
          }]
        }]
      }]
    }
  }
}
```

**关键数字**: 834/834 张戏单全部 API 拉取成功 · 每张含 Event（演出信息）+ PerformanceWork（剧目 + 演员 + 剧情梗概）

**与数据负责人1 的关系**: tickets_detail.json 是 API 原始数据，tickets.json（负责人1产出）是人工清洗修正后的数据。网站应以负责人1 的 tickets.json 为主要展示数据，tickets_detail.json 作为补充（如剧情梗概、演员 URI 等 API 独有的字段）。

---

### 2.4 images.json —— 实体图片索引

**一句话**: 一个小文件，直接从 entity_uri 查有没有照片，不用遍历 1.4MB 的 entities.json。

**结构**:
```json
{
  "person": {
    "<entity_uri>": {
      "name": "石玉昆",
      "image_url": "https://img.library.sh.cn/person/krq6wuwc28ykr9kp.jpg"
    }
  },
  "theater": {
    "<entity_uri>": {
      "name": "兰心大戏院",
      "images": [
        { "url": "https://img.library.sh.cn/shmemory/architecture/img/xxx.jpg",
          "description": "图为复名后的兰心大戏院" }
      ]
    }
  }
}
```

**关键数字**:
- 309 个人物有照片 · 4 家剧院各有约 17 张历史照片
- 覆盖 681/1,537 条关联关系（44.3%）
- 图片托管于 `img.library.sh.cn`，无需额外权限

---

## 三、这些文件怎么配合使用

### 数据流全景

```
用户打开某张戏单的详情页 (nid=1721 "圣母院")
          │
          ├──► tickets_detail.json["1721"]
          │       └── 拿到: 演出名、日期、场馆、演员表（姓名+角色+简介）、剧情梗概
          │
          ├──► relations.json (筛选 nid == 1721)
          │       └── 拿到: 4 条关联 → 单跃进(A)、杨乃林(A)、石玉昆(A)、上海京剧院(B)
          │
          ├──► images.json["person"][entity_uri]
          │       └── 拿到: 石玉昆照片 URL，单跃进、杨乃林无照片 → 显示文字头像
          │
          └──► entities.json[entity_uri]
                  └── 拿到: 上海京剧院成立日期、简介
```

### 前端加载策略

考虑到文件大小，建议按以下方式加载：

| 文件 | 大小 | 加载方式 |
|---|---|---|
| `relations.json` | 1.3 MB | 首次访问时加载一次，存入内存/IndexedDB |
| `entities.json` | 1.4 MB | **按需加载**——不用一次性全载入。用户打开详情页时才根据 entity_uri 取对应条目 |
| `tickets_detail.json` | 8.5 MB | **按需加载**——用户打开某张戏单时才取对应 nid 的数据 |
| `images.json` | 69 KB | 首次访问时加载，存内存 |

> 如果服务器上有后端，建议把这三个 JSON 导入数据库（MongoDB/SQLite），改成 API 调用而非前端直接读文件。

---

## 四、前端代码示例

### 4.1 查某张戏单的关联

```javascript
// 设 relations 已预加载为数组
function getRelationsForTicket(nid) {
  return relations.filter(r => r.nid === nid);
}

// 按实体类型分组
function groupRelations(relations) {
  return {
    persons:      relations.filter(r => r.entity_type === 'person'),
    organizations: relations.filter(r => r.entity_type === 'organization'),
    theaters:     relations.filter(r => r.entity_type === 'theater'),
    events:       relations.filter(r => r.entity_type === 'event'),
  };
}
```

### 4.2 查实体照片

```javascript
// 设 images 已预加载
function getEntityImage(entityType, entityUri) {
  const typeImages = images[entityType];
  if (!typeImages) return null;

  const entry = typeImages[entityUri];
  if (!entry) return null;

  // 人物返回单图，剧院返回数组
  if (entityType === 'person') return entry.image_url;
  if (entityType === 'theater') return entry.images; // [{url, description}]
  return null;
}
```

### 4.3 查实体详情

```javascript
function getEntityDetail(entityUri) {
  return entities[entityUri] || null;
}

// 获取人物显示名称
function getPersonDisplayName(entityUri) {
  const e = getEntityDetail(entityUri);
  if (!e || !e.api_success) return '未知';
  return e.clean_name;
}
```

### 4.4 证据等级徽章

```javascript
function getEvidenceBadge(level) {
  switch (level) {
    case 'A': return { text: '直接关联', color: '#2563eb', icon: '🔵' };
    case 'B': return { text: '推断关联', color: '#16a34a', icon: '🟢' };
    default: return { text: '未知',    color: '#9ca3af', icon: '⚪' };
  }
}
```

### 4.5 无关联戏单的处理

```javascript
const ticketRelations = getRelationsForTicket(nid);

if (ticketRelations.length === 0) {
  // 显示:
  // "上海图书馆开放数据暂未检出可确认关联"
  // 但仍可正常展示 tickets_detail.json 中的基本信息
}
```

---

## 五、需要知道的数据边界

### 有的
- ✅ 1,537 条核验过的关联，覆盖 561 张戏单
- ✅ 601 个人物的基本信息（姓名、关联机构、部分有生平和照片）
- ✅ 45 家机构的成立日期和简介
- ✅ 4 家剧院的地址、经纬度、历史沿革、68 张历史照片
- ✅ 834 张戏单的完整 API 数据（演员表全文、剧情梗概）
- ✅ A/B 级证据区分，所有关系经人工复核

### 没有的（需要知道的原因）

| 缺失项 | 原因 |
|---|---|
| **戏单原图（扫描件）** | API 不返回图片 URL，Excel 中"原始资源链接"列全部为空 |
| **292 个人物的照片** | 上图人物数据库 `hasFile` = 0，这些人确实没有照片 |
| **机构照片/Logo** | 机构 API 不返回图片字段 |
| **1 个建筑实体详情** | API 调用失败（gmwx 端点返回 -1） |
| **273 张无关联戏单** | 它们的演员/场馆在上图数据库中检索不到匹配实体 |

---

## 六、如何更新数据

如果 Excel 源文件更新了（比如人工复核结论变了），重新生成数据：

```bash
# 1. 重新提取关联关系
python extract_relations.py    # → 覆盖 relations.json

# 2. 重新拉取实体详情（如果关联变了会有新 URI）
python fetch_entities.py       # → 覆盖 entities.json + entities_failed.csv

# 3. 重新拉取戏单详情
python fetch_tickets.py        # → 覆盖 tickets_detail.json

# 4. 重新提取图片索引
python build_images.py         # → 覆盖 images.json

# 5. 验证数据
python data_check.py           # → 覆盖 data_check.md
python verify_all.py           # → 控制台输出验证结果
```

---

## 七、文件清单（完整）

```
一票入场_data/
├── 📊 relations.json         1,537 条关联关系（网站直接导入）
├── 📊 entities.json           652 个实体百科详情
├── 📊 tickets_detail.json     834 张戏单完整 API 数据
├── 📊 images.json             313 个实体的图片 URL 索引
├── 📊 entities_failed.csv      1 个 API 失败记录
├── 📄 data_dictionary.md      完整字段定义与枚举说明
├── 📄 data_check.md           质检报告（全部通过）
├── 📄 README.md               本文件
├── 🔧 extract_relations.py   从 Excel 重新生成 relations.json
├── 🔧 fetch_entities.py       拉取实体详情 API
├── 🔧 fetch_tickets.py        拉取戏单详情 API
├── 🔧 build_images.py         从 entities.json 提取图片索引
├── 🔧 data_check.py           运行数据质检
└── 🔧 verify_all.py           快速完整性验证
```

---

## 八、给网站组的对接要点

1. **主数据源**: 以数据负责人1 的 `tickets.json`（834 张戏单清洗后数据）为主，本目录的 `relations.json` 提供关联，`entities.json` 提供详情
2. **按 nid 关联**: 所有文件通过 `nid` 或 `entity_uri` 互相关联，不需要复杂 join
3. **图片降级**: 查得到照片就显示，查不到就显示文字首字母头像——不要留空或报错
4. **证据等级**: A 级和 B 级在 UI 上应有视觉区分（如不同颜色徽章），让用户知道可信度差异
5. **无关联不报错**: 273 张戏单在 relations 中查不到是正常的，显示"暂未检出可确认关联"即可
6. **entity_name 去后缀**: 展示前去掉 `@chs` `@en` `@cht` 后缀，或用 `clean_name` 字段
