"""
从 entities.json 中提取所有图片 URL, 输出 images.json
"""
import json, os

with open('entities.json', 'r', encoding='utf-8') as f:
    ents = json.load(f)

images = {'person': {}, 'organization': {}, 'theater': {}, 'event': {}, 'architecture': {}}

for uri, e in ents.items():
    t = e['entity_type']
    if not e['api_success']:
        continue
    d = e['api_data']
    if not isinstance(d, dict):
        continue

    if t == 'person':
        data = d.get('data', d)
        if isinstance(data, dict):
            img = data.get('img')
            if img:
                if img.startswith('//'):
                    img = 'https:' + img
                images['person'][uri] = {
                    'name': e['clean_name'],
                    'image_url': img,
                }

    elif t == 'theater':
        data = d.get('data', d)
        if isinstance(data, list):
            theater_imgs = []
            for item in data:
                # Images are in architecture sub-object
                arch = item.get('architecture', {})
                if isinstance(arch, dict):
                    # imagesList: direct images of the theater
                    for img_obj in arch.get('imagesList', []):
                        url = img_obj.get('imgP') or img_obj.get('imageUri', '')
                        if url:
                            if url.startswith('//'): url = 'https:' + url
                            theater_imgs.append({'url': url, 'description': img_obj.get('description', '')})
                    # eventList: historical event images
                    for evt in arch.get('eventList', []):
                        url = evt.get('imgP') or evt.get('imageUri', '')
                        if url:
                            if url.startswith('//'): url = 'https:' + url
                            theater_imgs.append({'url': url, 'description': evt.get('imageDescription', '')})
            if theater_imgs:
                images['theater'][uri] = {
                    'name': e['clean_name'],
                    'images': theater_imgs,
                }

    elif t == 'organization':
        data = d.get('data', d)
        if isinstance(data, dict):
            img = data.get('img') or data.get('image') or data.get('logo')
            if img:
                if img.startswith('//'):
                    img = 'https:' + img
                images['organization'][uri] = {
                    'name': e['clean_name'],
                    'image_url': img,
                }

    elif t == 'event':
        data = d.get('data', d)
        if isinstance(data, list):
            for item in data:
                imgs = item.get('imageList', [])
                if imgs:
                    images['event'][uri] = {
                        'name': e['clean_name'],
                        'images': imgs,
                    }

# Summary
total = sum(len(v) for v in images.values())
print("=" * 50)
print(f"提取图片汇总: {total} 个实体有图片")
for t, imgs in sorted(images.items()):
    count = len(imgs)
    if count > 0:
        print(f"  {t}: {count}")
        # 列出前3个
        sample_uris = list(imgs.keys())[:2]
        for u in sample_uris:
            info = imgs[u]
            name = info.get('name', '?')
            urls = info.get('image_url') or [x['url'] for x in info.get('images', [])]
            if isinstance(urls, str):
                urls = [urls]
            for url in urls[:2]:
                print(f"    {name}: {url[:100]}")

# 输出
output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'images.json')
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(images, f, ensure_ascii=False, indent=2)
print(f"\nimages.json -> {output_path} ({os.path.getsize(output_path):,} bytes)")

# 对应回 relations: 哪些 relation 对应的实体有图
with open('relations.json', 'r', encoding='utf-8') as f:
    rels = json.load(f)

rels_with_img = 0
for r in rels:
    uri = r['entity_uri']
    t = r['entity_type']
    if uri in images.get(t, {}):
        rels_with_img += 1

print(f"\n有图的关联关系: {rels_with_img}/{len(rels)} ({rels_with_img/len(rels)*100:.1f}%)")
