import json, os

with open('relations.json', 'r', encoding='utf-8') as f:
    rels = json.load(f)

print('=== relations.json 最终验证 ===')
print(f'记录数: {len(rels)}')
print(f'字段: {list(rels[0].keys())}')

# Verify counts
assert len(rels) == 1537, f'FAIL: expected 1537, got {len(rels)}'
print('✅ 关系数 = 1537')

rids = [r['relation_id'] for r in rels]
assert len(rids) == len(set(rids)), 'FAIL: duplicate relation_id'
print('✅ relation_id 无重复')

assert all(r['evidence_level'] in ('A','B') for r in rels)
print('✅ 证据等级均为 A/B')

# No 57 values
found_57 = False
for r in rels:
    for k, v in r.items():
        if v == '57' or v == 57:
            print(f'❌ Found 57 in {r["relation_id"]}.{k}')
            found_57 = True
if not found_57:
    print('✅ 无 "57" 占位值')

nids = set(r['nid'] for r in rels)
assert len(nids) == 561, f'FAIL: expected 561 nids, got {len(nids)}'
print(f'✅ 唯一 nid = {len(nids)}')

# All review_status is 已核验
statuses = set(r['review_status'] for r in rels)
print(f'✅ 审核状态: {statuses}')

# Entity types
from collections import Counter
types = Counter(r['entity_type'] for r in rels)
print(f'✅ 实体类型: person={types["person"]}, org={types["organization"]}, theater={types["theater"]}, event={types["event"]}, arch={types["architecture"]}')

levels = Counter(r['evidence_level'] for r in rels)
print(f'✅ 证据等级: A={levels["A"]}, B={levels["B"]}')

print()
print('所有交付文件:')
for f in sorted(os.listdir('.')):
    if f.endswith(('.json','.md','.py')) and not f.startswith('check_'):
        size = os.path.getsize(f)
        print(f'  {f} ({size:,} bytes)')

print()
print('🎉 全部验证通过！')
