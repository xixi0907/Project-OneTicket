"""
fetch_tickets.py
================
通过上海图书馆戏单详情 API (/webapi/xd/detail) 获取 834 张戏单的完整结构化数据。

使用方法:
    python fetch_tickets.py

前置条件:
    pip install requests
    需要 relations.json（从中提取 834 个 nid，或从 tickets.json 获取）

输入:
    可选: tickets.json 或 relations.json（提取所有 nid）
    如无以上文件，将从 Excel 直接读取 834 个 nid

输出:
    tickets_detail.json — 每个 nid 的 API 返回数据
    tickets_failed.csv  — 调用失败的 nid 及原因
"""

import requests
import json
import csv
import os
import time
import urllib3
from urllib.parse import urljoin

urllib3.disable_warnings()

# ============================================================
# 配置
# ============================================================
API_KEY = "bd61d7fb65d80cc534a56529444ced78cca63c51"
API_BASE_URL = "https://data.library.sh.cn/"

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

REQUEST_DELAY = 0.15
MAX_RETRIES = 1

TICKET_DETAIL_ENDPOINT = "webapi/xd/detail"


def get_all_nids() -> list[int]:
    """从 relations.json 或 Excel 获取全部 834 个 nid"""
    # 方法1: 从 relations.json
    relations_path = os.path.join(OUTPUT_DIR, "relations.json")
    if os.path.exists(relations_path):
        with open(relations_path, "r", encoding="utf-8") as f:
            relations = json.load(f)
        nids_from_rel = set(r["nid"] for r in relations)
        print(f"从 relations.json 提取到 {len(nids_from_rel)} 个关联 nid")

    # 方法2: 从 tickets.json
    tickets_path = os.path.join(OUTPUT_DIR, "tickets.json")
    if os.path.exists(tickets_path):
        with open(tickets_path, "r", encoding="utf-8") as f:
            tickets = json.load(f)
        all_nids = set(t["nid"] for t in tickets)
        print(f"从 tickets.json 提取到 {len(all_nids)} 个 nid（全部戏单）")
        return sorted(all_nids)

    # 方法3: 如果 tickets.json 还不存在，从 Excel 提取
    excel_path = r"D:\微信\xwechat_files\wxid_rfz3l5atdfmf22_8fef\temp\RWTemp\2026-08\a05af3a485e780e89c8adff6dbc32d44\一票入场_834条最终关联审核结果_20260727.xlsx"
    if os.path.exists(excel_path):
        import openpyxl
        print(f"从 Excel (08_戏单总表) 提取 nid...")
        wb = openpyxl.load_workbook(excel_path, data_only=True)
        ws = wb["08_戏单总表"]
        nids = []
        for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=1, max_col=1, values_only=True):
            if row[0] is not None:
                nids.append(int(row[0]))
        print(f"从 Excel 提取到 {len(nids)} 个 nid")
        return sorted(nids)

    print("⚠️ 找不到 nid 来源文件，请先生成 tickets.json 或 relations.json")
    return []


def fetch_ticket_detail(nid: int, session: requests.Session) -> dict:
    """调用 /webapi/xd/detail 获取戏单详情"""
    url = urljoin(API_BASE_URL, TICKET_DETAIL_ENDPOINT)
    params = {"key": API_KEY, "nid": nid}

    last_error = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            resp = session.get(url, params=params, timeout=30, verify=False)
            if resp.status_code == 200:
                return {
                    "success": True,
                    "nid": nid,
                    "data": resp.json() if "application/json" in resp.headers.get("content-type", "") else resp.text,
                }
            elif resp.status_code == 404:
                last_error = f"HTTP 404: nid={nid} 不存在"
                break
            elif resp.status_code == 403:
                last_error = f"HTTP 403: API Key 无效或权限不足"
                break
            elif resp.status_code == 429:
                time.sleep(2 * (attempt + 1))
                last_error = f"HTTP 429 (Rate limit)"
            else:
                last_error = f"HTTP {resp.status_code}"
                if attempt < MAX_RETRIES:
                    time.sleep(1)
        except requests.exceptions.Timeout:
            last_error = "Timeout"
            if attempt < MAX_RETRIES:
                time.sleep(2)
        except Exception as e:
            last_error = f"{type(e).__name__}: {e}"
            break

    return {"success": False, "nid": nid, "data": None, "error": last_error}


def main():
    nids = get_all_nids()
    if not nids:
        return

    total = len(nids)
    print(f"共 {total} 个 nid 需要获取详情\n")

    session = requests.Session()
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    })

    results = {}
    failed = []

    for i, nid in enumerate(nids):
        pct = (i + 1) / total * 100
        print(f"\r🔄 [{i+1}/{total}] {pct:.1f}% | nid={nid}", end="", flush=True)

        result = fetch_ticket_detail(nid, session)
        results[str(nid)] = result

        if not result["success"]:
            failed.append({"nid": nid, "error": result.get("error", "Unknown")})

        time.sleep(REQUEST_DELAY)

    print()

    # --- 输出 ---
    output_path = os.path.join(OUTPUT_DIR, "tickets_detail.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"✅ tickets_detail.json → {output_path}")

    if failed:
        csv_path = os.path.join(OUTPUT_DIR, "tickets_failed.csv")
        with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["nid", "error"])
            writer.writeheader()
            for item in failed:
                writer.writerow(item)
        print(f"⚠️ tickets_failed.csv → {csv_path} ({len(failed)} 条失败)")

    print(f"\n总计: {total}, 成功: {total - len(failed)}, 失败: {len(failed)}")


if __name__ == "__main__":
    main()
