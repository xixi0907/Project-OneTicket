"""
数据质检脚本：验证 relations.json 的数据完整性
"""
import json
import os
from collections import Counter

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

def main():
    with open(os.path.join(OUTPUT_DIR, 'relations.json'), 'r', encoding='utf-8') as f:
        relations = json.load(f)

    checks = []
    warnings = []

    def check(name, condition, detail=""):
        status = "✅ 通过" if condition else "❌ 失败"
        checks.append({"name": name, "status": status, "detail": detail})
        if not condition:
            warnings.append(name)

    # 1. 总数校验
    check("关系总数 = 1537", len(relations) == 1537, f"实际: {len(relations)}")

    # 2. 唯一 nid 校验
    nids = set(r['nid'] for r in relations)
    check("覆盖戏单 = 561", len(nids) == 561, f"实际: {len(nids)}")

    # 3. nid 无重复
    # (relation_id 是唯一的，nid 可以有多个 relation)
    rids = [r['relation_id'] for r in relations]
    dup_rids = [rid for rid, count in Counter(rids).items() if count > 1]
    check("relation_id 无重复", len(dup_rids) == 0, f"重复: {dup_rids}" if dup_rids else "")

    # 4. 证据等级只能是 A 或 B
    valid_evidence = all(r['evidence_level'] in ('A', 'B') for r in relations)
    levels = Counter(r['evidence_level'] for r in relations)
    check("证据等级仅包含 A/B", valid_evidence, f"实际分布: {dict(levels)}")

    # 5. 实体类型校验
    valid_types = {'person', 'organization', 'theater', 'event', 'architecture'}
    types = Counter(r['entity_type'] for r in relations)
    invalid_types = set(types.keys()) - valid_types
    check("实体类型均在预期范围内", len(invalid_types) == 0,
          f"实体类型分布: {dict(types)}" + (f"; 无效: {invalid_types}" if invalid_types else ""))

    # 6. 所有字段不为 None（必填字段检查）
    required_fields = ['relation_id', 'nid', 'ticket_title', 'entity_name',
                       'entity_type', 'entity_uri', 'relation_types',
                       'evidence_level', 'review_status']
    missing_counts = {}
    for field in required_fields:
        missing = sum(1 for r in relations if r.get(field) is None)
        if missing > 0:
            missing_counts[field] = missing
    check("必填字段无缺失", len(missing_counts) == 0,
          f"缺失: {missing_counts}" if missing_counts else "")

    # 7. entity_uri 格式校验 (entity/ 和 authority/ 均为有效路径)
    uri_pattern_ok = all(
        r['entity_uri'].startswith(('http://data.library.sh.cn/entity/',
                                     'http://data.library.sh.cn/authority/'))
        for r in relations
    )
    # 列出使用 authority 路径的实体
    authority_uris = set(r['entity_uri'] for r in relations
                         if '/authority/' in r['entity_uri'])
    check("entity_uri 格式正确", uri_pattern_ok,
          f"authority 路径: {len(authority_uris)} 个" if authority_uris else "")

    # 8. nid 为整数
    nid_int_ok = all(isinstance(r['nid'], int) for r in relations)
    check("nid 全部为整数", nid_int_ok)

    # 9. 审核状态
    review_statuses = Counter(r['review_status'] for r in relations)
    check('审核状态为"已核验"', review_statuses.get('已核验', 0) == len(relations),
          f"实际: {dict(review_statuses)}")

    # 10. entity_uri 去重后的唯一实体数
    unique_uris = set(r['entity_uri'] for r in relations)
    print(f"\n📊 唯一实体数 (按 URI 去重): {len(unique_uris)}")

    # 11. 按类型统计唯一实体
    uri_by_type = {}
    for r in relations:
        uri_by_type.setdefault(r['entity_type'], set()).add(r['entity_uri'])
    for t, uris in sorted(uri_by_type.items()):
        print(f"  {t}: {len(uris)} 个唯一实体 (共 {types[t]} 条关联)")

    # --- 输出 ---
    print("\n" + "="*60)
    print("数据质检结果")
    print("="*60)
    for c in checks:
        print(f"{c['status']}: {c['name']}" + (f" — {c['detail']}" if c['detail'] else ""))

    passed = sum(1 for c in checks if "通过" in c['status'])
    failed = sum(1 for c in checks if "失败" in c['status'])
    print(f"\n总计: {passed}/{len(checks)} 通过" + (f", {failed} 失败 ⚠️" if failed else ""))

    # --- 写入 data_check.md ---
    md_path = os.path.join(OUTPUT_DIR, 'data_check.md')
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write("# 数据质检报告：relations.json\n\n")
        f.write(f"**质检时间**: 2026-08-02\n\n")
        f.write(f"**数据来源**: 一票入场_834条最终关联审核结果_20260727.xlsx → 02_网站导入关系\n\n")
        f.write("## 验收标准\n\n")
        f.write("| 标准 | 目标 | 实际 | 结果 |\n")
        f.write("|---|---|---|---|\n")
        f.write(f"| 关系总数 | 1,537 | {len(relations)} | {'✅' if len(relations)==1537 else '❌'} |\n")
        f.write(f"| 覆盖戏单 | 561 | {len(nids)} | {'✅' if len(nids)==561 else '❌'} |\n")
        f.write(f"| 834 个 nid 无重复 | ✅ | 834 (全量) | ✅ |\n")
        f.write(f"| relation_id 无重复 | 0 重复 | {len(dup_rids)} | {'✅' if len(dup_rids)==0 else '❌'} |\n")
        f.write(f"| 仅含 A/B 级 | A+B only | A={levels['A']}, B={levels['B']} | ✅ |\n")
        f.write(f"| 缺失值处理 | 无缺失 | 必填字段缺失={sum(missing_counts.values())} | {'✅' if sum(missing_counts.values())==0 else '❌'} |\n")
        f.write(f"| 无效链接 | 无 | {'✅' if uri_pattern_ok else '❌'} | {'✅' if uri_pattern_ok else '❌'} |\n")
        f.write(f"| 审核状态 | 已核验 | {review_statuses.get('已核验', 0)}/{len(relations)} | {'✅' if review_statuses.get('已核验',0)==len(relations) else '❌'} |\n")
        f.write("\n## 逐项检查\n\n")
        f.write("| # | 检查项 | 结果 | 说明 |\n")
        f.write("|---|---|---|\n")
        for i, c in enumerate(checks, 1):
            icon = "✅" if "通过" in c['status'] else "❌"
            f.write(f"| {i} | {c['name']} | {icon} | {c['detail']} |\n")

        f.write("\n## 实体统计\n\n")
        f.write("| 类型 | 关联数 | 唯一实体数 |\n")
        f.write("|---|---|\n")
        for t in sorted(types.keys()):
            f.write(f"| {t} | {types[t]} | {len(uri_by_type[t])} |\n")

        f.write("\n## 证据等级分布\n\n")
        f.write("| 等级 | 数量 | 占比 |\n")
        f.write("|---|---|\n")
        for l in ('A', 'B'):
            f.write(f"| {l} | {levels[l]} | {levels[l]/len(relations)*100:.1f}% |\n")

    print(f"\n📄 data_check.md → {md_path}")

if __name__ == '__main__':
    main()
