"""
从《一票入场_834条最终关联审核结果_20260727.xlsx》的 02_网站导入关系 sheet
提取已核验的 A/B 级关系，生成 relations.json
"""
import openpyxl
import json
import os
from collections import Counter

# --- Config ---
XLSX_PATH = r"D:\微信\xwechat_files\wxid_rfz3l5atdfmf22_8fef\temp\RWTemp\2026-08\a05af3a485e780e89c8adff6dbc32d44\一票入场_834条最终关联审核结果_20260727.xlsx"
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

def clean_value(v):
    """将 None、'None'、'57' 转为 null，去首尾空白"""
    if v is None:
        return None
    if str(v).strip() == 'None' or str(v).strip() == '' or str(v).strip() == '57':
        return None
    return str(v).strip()

def main():
    print(f"Reading: {XLSX_PATH}")
    wb = openpyxl.load_workbook(XLSX_PATH, data_only=True)

    # Sheet 02_网站导入关系
    ws = wb['02_网站导入关系']
    print(f"Sheet rows: {ws.max_row}, cols: {ws.max_column}")

    # Read header row
    headers = []
    for cell in ws[1]:
        headers.append(str(cell.value) if cell.value else '')

    print(f"Headers: {headers}")

    # Column mapping
    # relation_id, nid, ticket_title, entity_name, entity_type, entity_uri,
    # relation_types, mention_texts, source_fields, dataset_name,
    # evidence_level, review_status, evidence_text

    relations = []
    seen_ids = set()
    skipped_non_ab = []
    skipped_duplicate = []
    errors = []

    for row_idx in range(2, ws.max_row + 1):
        row_data = {}
        for col_idx, header in enumerate(headers):
            cell = ws.cell(row=row_idx, column=col_idx + 1)
            row_data[header] = clean_value(cell.value)

        # --- Filters ---
        # Only import A/B level
        evidence = row_data.get('evidence_level', '')
        if evidence not in ('A', 'B'):
            skipped_non_ab.append({
                'relation_id': row_data.get('relation_id'),
                'evidence_level': evidence,
                'entity_name': row_data.get('entity_name'),
                'reason': f'证据等级为"{evidence}"，非A/B级'
            })
            continue

        # Deduplicate
        rid = row_data.get('relation_id')
        if rid in seen_ids:
            skipped_duplicate.append(rid)
            continue
        seen_ids.add(rid)

        # --- Build record ---
        nid_str = row_data.get('nid')
        # Validate nid
        try:
            nid_int = int(nid_str)
        except (TypeError, ValueError):
            errors.append(f"REL {rid}: invalid nid '{nid_str}'")
            continue

        record = {
            "relation_id": rid,
            "nid": nid_int,
            "ticket_title": row_data.get('ticket_title'),
            "entity_name": row_data.get('entity_name'),
            "entity_type": row_data.get('entity_type'),
            "entity_uri": row_data.get('entity_uri'),
            "relation_types": row_data.get('relation_types'),
            "mention_texts": row_data.get('mention_texts'),
            "source_fields": row_data.get('source_fields'),
            "dataset_name": row_data.get('dataset_name'),
            "evidence_level": evidence,
            "review_status": row_data.get('review_status'),
            "evidence_text": row_data.get('evidence_text')
        }
        relations.append(record)

    # --- Summary ---
    nids = set(r['nid'] for r in relations)
    entity_types = Counter(r['entity_type'] for r in relations)
    evidence_levels = Counter(r['evidence_level'] for r in relations)

    print(f"\n=== 提取结果 ===")
    print(f"总提取关系: {len(relations)}")
    print(f"覆盖戏单(nid): {len(nids)}")
    print(f"跳过(非A/B级): {len(skipped_non_ab)}")
    print(f"跳过(重复ID): {len(skipped_duplicate)}")
    print(f"错误: {len(errors)}")
    print(f"\n实体类型分布:")
    for t, c in entity_types.most_common():
        print(f"  {t}: {c}")
    print(f"\n证据等级分布:")
    for l, c in evidence_levels.most_common():
        print(f"  {l}: {c}")

    # --- Output ---
    output_path = os.path.join(OUTPUT_DIR, 'relations.json')
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(relations, f, ensure_ascii=False, indent=2)
    print(f"\n✅ relations.json → {output_path}")

    # --- Skips log ---
    if skipped_non_ab:
        skip_path = os.path.join(OUTPUT_DIR, 'relations_skipped_non_ab.json')
        with open(skip_path, 'w', encoding='utf-8') as f:
            json.dump(skipped_non_ab, f, ensure_ascii=False, indent=2)
        print(f"📋 非A/B级记录 → {skip_path}")

    if errors:
        err_path = os.path.join(OUTPUT_DIR, 'relations_errors.json')
        with open(err_path, 'w', encoding='utf-8') as f:
            json.dump(errors, f, ensure_ascii=False, indent=2)
        print(f"⚠️ 错误记录 → {err_path}")

    return relations, nids, entity_types

if __name__ == '__main__':
    main()
