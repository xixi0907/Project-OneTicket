"""
fetch_entities.py
=================
根据 relations.json 中的 entity_uri，通过上海图书馆开放数据 API 获取每个实体的详细信息。

实测端点与参数（2026-08-02 验证通过）:

| entity_type   | API endpoint                                    | 参数 |
|---------------|-------------------------------------------------|------|
| person        | /shnh/wkl/webapi/persons/detail                 | uri  |
| organization  | /shnh/whzk/webapi/org/detail                    | uri  |
| theater       | /shnh/dydata/webapi/architecture/architectureDetail | uri  |
| event         | /webapi/hsly/route/getEventDetail               | uri  |
| architecture  | /shnh/gmwx/webapi/architecture/getArchitectureDetail | uri  |

用法:
    python fetch_entities.py
"""

import requests
import json
import csv
import os
import re
import time
import urllib3
from urllib.parse import urljoin

urllib3.disable_warnings()

# ============================================================
# 配置
# ============================================================
API_KEY = "bd61d7fb65d80cc534a56529444ced78cca63c51"
API_BASE_URL = "https://data.library.sh.cn/"

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))
REQUEST_DELAY = 0.15  # 请求间隔（秒）
MAX_RETRIES = 1

# ============================================================
# 端点映射（均使用 uri 参数）
# ============================================================
ENDPOINT_MAP = {
    "person": "shnh/wkl/webapi/persons/detail",
    "organization": "shnh/whzk/webapi/org/detail",
    "theater": "shnh/dydata/webapi/architecture/architectureDetail",
    "event": "webapi/hsly/route/getEventDetail",
    "architecture": "shnh/gmwx/webapi/architecture/getArchitectureDetail",
}


def clean_entity_name(name: str) -> str:
    """去除上图内部的 @chs 等标注"""
    if name:
        return re.sub(r"@\w+$", "", name)
    return name


def is_success_response(data) -> bool:
    """判断 API 返回是否成功"""
    if data is None:
        return False
    if isinstance(data, dict):
        # result: "0" 表示成功, "1" 或 "-1" 表示失败
        if data.get("result") in ("1", "-1", 1, -1):
            return False
        # 有 data 字段且非空
        if "data" in data and data["data"]:
            return True
        # 直接有内容字段
        if any(k in data for k in ["cht_name", "chs_name", "description", "name", "title"]):
            return True
    if isinstance(data, list) and len(data) > 0:
        return True
    if isinstance(data, str) and len(data) > 10:
        return True
    return False


def fetch_entity(entity_type: str, entity_uri: str, session: requests.Session) -> dict:
    """调用 API 获取实体详情"""
    endpoint = ENDPOINT_MAP.get(entity_type)
    if not endpoint:
        return {
            "success": False, "data": None, "endpoint": None,
            "entity_type": entity_type, "entity_uri": entity_uri,
            "error": f"Unknown entity_type: {entity_type}",
        }

    url = urljoin(API_BASE_URL, endpoint)
    params = {"key": API_KEY, "uri": entity_uri}

    last_error = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            resp = session.get(url, params=params, timeout=30, verify=False)

            if resp.status_code == 200:
                try:
                    data = resp.json()
                except Exception:
                    data = resp.text

                if is_success_response(data):
                    return {
                        "success": True,
                        "data": data,
                        "endpoint": endpoint,
                        "entity_type": entity_type,
                        "entity_uri": entity_uri,
                    }
                else:
                    last_error = f"API returned failure: {json.dumps(data, ensure_ascii=False)[:200]}"
                    break  # 数据就是失败，换端点也没用

            elif resp.status_code == 404:
                last_error = f"HTTP 404: {endpoint}"
                break
            elif resp.status_code == 403:
                last_error = f"HTTP 403: API Key 无效或权限不足"
                break
            elif resp.status_code == 429:
                time.sleep(2 * (attempt + 1))
                last_error = f"HTTP 429 (rate limited)"
            else:
                last_error = f"HTTP {resp.status_code}"
                if attempt < MAX_RETRIES:
                    time.sleep(1)

        except requests.exceptions.Timeout:
            last_error = "Timeout"
            if attempt < MAX_RETRIES:
                time.sleep(2)
        except requests.exceptions.ConnectionError as e:
            last_error = f"Connection error: {str(e)[:100]}"
            break
        except Exception as e:
            last_error = f"{type(e).__name__}: {str(e)[:100]}"
            break

    return {
        "success": False, "data": None, "endpoint": endpoint,
        "entity_type": entity_type, "entity_uri": entity_uri,
        "error": last_error,
    }


def main():
    # 读取 relations.json
    relations_path = os.path.join(OUTPUT_DIR, "relations.json")
    print(f"📂 读取 {relations_path}...")
    with open(relations_path, "r", encoding="utf-8") as f:
        relations = json.load(f)
    print(f"   共 {len(relations)} 条关联关系")

    # 按 entity_uri 去重
    entity_map = {}
    for r in relations:
        uri = r["entity_uri"]
        if uri not in entity_map:
            entity_map[uri] = {
                "entity_uri": uri,
                "entity_type": r["entity_type"],
                "entity_name": r["entity_name"],
                "clean_name": clean_entity_name(r["entity_name"]),
                "related_nids": [],
            }
        entity_map[uri]["related_nids"].append(r["nid"])

    unique_entities = list(entity_map.values())
    total = len(unique_entities)
    print(f"📊 唯一实体: {total} 个")

    type_counts = {}
    for e in unique_entities:
        type_counts[e["entity_type"]] = type_counts.get(e["entity_type"], 0) + 1
    print("   类型分布:")
    for t, c in sorted(type_counts.items()):
        print(f"     {t}: {c}")

    # HTTP session
    session = requests.Session()
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    })

    # 逐实体请求
    failed = []
    entities_output = {}

    for i, entity in enumerate(unique_entities):
        uri = entity["entity_uri"]
        etype = entity["entity_type"]
        pct = (i + 1) / total * 100

        # 进度（每 10 个或最后打印一次）
        if (i + 1) % 10 == 0 or i == 0 or i == total - 1:
            print(f"\r🔄 [{i+1}/{total}] {pct:.1f}% | {etype}: {entity['clean_name'][:20]}", end="", flush=True)

        result = fetch_entity(etype, uri, session)

        entities_output[uri] = {
            "entity_uri": uri,
            "entity_type": etype,
            "entity_name": entity["entity_name"],
            "clean_name": entity["clean_name"],
            "related_nids": entity["related_nids"],
            "api_success": result["success"],
            "api_endpoint": result["endpoint"],
            "api_data": result["data"],
            "api_error": result.get("error"),
        }

        if not result["success"]:
            failed.append({
                "entity_uri": uri,
                "entity_type": etype,
                "entity_name": entity["entity_name"],
                "error": result.get("error", "Unknown"),
                "related_nids_count": len(entity["related_nids"]),
            })

        time.sleep(REQUEST_DELAY)

    print()

    # --- 输出 ---
    output_path = os.path.join(OUTPUT_DIR, "entities.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(entities_output, f, ensure_ascii=False, indent=2)
    print(f"✅ entities.json → {output_path} ({os.path.getsize(output_path):,} bytes)")

    if failed:
        csv_path = os.path.join(OUTPUT_DIR, "entities_failed.csv")
        with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(failed[0].keys()))
            writer.writeheader()
            for item in failed:
                writer.writerow(item)
        print(f"⚠️ entities_failed.csv → {csv_path} ({len(failed)} 条失败)")

    # 汇总
    success_count = total - len(failed)
    print(f"\n{'='*50}")
    print(f"总计: {total} | 成功: {success_count} | 失败: {len(failed)}")
    print(f"成功率: {success_count/total*100:.1f}%")

    if failed:
        fail_types = {}
        for f_item in failed:
            t = f_item["entity_type"]
            fail_types[t] = fail_types.get(t, 0) + 1
        print("失败分布:")
        for t, c in sorted(fail_types.items()):
            print(f"  {t}: {c}/{type_counts.get(t, 0)}")

    # 清理临时文件
    for f in ["test_api.py", "test_api2.py", "test_api3.py", "test_api4.py"]:
        p = os.path.join(OUTPUT_DIR, f)
        if os.path.exists(p):
            os.remove(p)

    return success_count, len(failed)


if __name__ == "__main__":
    main()
