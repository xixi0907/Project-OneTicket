# 《一票入场》地图数据 V0.1

## 数据边界

- 场馆名称、地址、戏单与场馆的关联，均来自上海图书馆开放数据的 `tickets.json` 与 `venues.json`；
- 高德地图只承担“已有地址 → 坐标”的技术定位，不能补写场馆历史、地址、人物或演出事实；
- 没有具体上海地址的戏单不应强行落点，应显示“地点待细化”。

## 文件说明

- `map_venues.json`：前端地图的场馆点输入。坐标尚未生成，不能直接放在地图上；
- `map_ticket_index.json`：按 `nid` 将有场馆的戏单连到场馆点；
- `map_manual_review.json`：含多地址写法、无具体地址或其他需要人工查看的点；
- `map_data_check.json`：生成与质量检查结果；
- `map_venues_geocoded.json`：运行高德脚本后生成，才可供地图使用；
- `amap_geocoding_report.json`：高德批量定位结果。

## 网站读取规则

1. 未生成 `map_venues_geocoded.json` 时，地图页显示“正在补充坐标”，不能用假坐标占位。
2. 只渲染 `coordinate` 存在、且 `geocoding_status` 为 `amap_geocoded_needs_spot_check` 或 `amap_spot_checked` 的点。
3. 点击点后，用 `ticket_nids` / `map_ticket_index.json` 找到对应戏单；点内展示原始场馆写法、上图戏单地址和相关戏票数量。
4. `open_data_theater_uris` 不为空的点可另加“上图开放数据已匹配历史影剧院”标识；这不是所有场馆都会有的资料。
5. 高德返回的是 `GCJ-02` 坐标，前端底图必须同为高德坐标体系，不能混用其他坐标系。

## 生成坐标

### Windows 推荐操作（不需要安装 Python）

1. 解压本压缩包；
2. 双击 `START_MAP_GEOCODING.cmd`；
3. 出现提示后粘贴自己的高德 Web 服务 Key；输入内容不会显示；
4. 程序完成后，文件夹中会生成 `map_venues_geocoded.json` 与 `amap_geocoding_report.json`。

如果 Windows 弹出“是否运行”提示，请选择“仍要运行”。如果双击后窗口立即关闭，请在文件夹空白处按住 Shift 并右键，选择“在终端中打开”，再运行：

```powershell
.\run_map_geocoding.ps1
```

### 其他终端

数据负责人也可继续使用 Python 版本，在本地终端临时设置自己的高德 Key 后运行：

```bash
AMAP_API_KEY='自己的Key' python3 geocode_amap.py
```

Key 只能放在本机环境变量中，不写进代码、JSON、GitHub 或共享文档。运行后先抽查高频场馆与多地址点，再将 `map_venues_geocoded.json` 交给网站组。
