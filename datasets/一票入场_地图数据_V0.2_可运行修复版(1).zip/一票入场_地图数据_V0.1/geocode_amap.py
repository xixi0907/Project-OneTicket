#!/usr/bin/env python3
"""Geocode prepared venue addresses with AMap and validate the results.

Usage (do not put the key in GitHub or shared documents):
  AMAP_API_KEY='...' python3 geocode_amap.py
"""

from __future__ import annotations

import json
import os
import time
import urllib.parse
import urllib.request
from datetime import date
from pathlib import Path


# This script is shipped inside the data package, alongside its input files.
DATA_DIR = Path(__file__).resolve().parent
INPUT = DATA_DIR / "map_venues.json"
OUTPUT = DATA_DIR / "map_venues_geocoded.json"
REPORT = DATA_DIR / "amap_geocoding_report.json"


def in_shanghai(lon: float, lat: float) -> bool:
    return 120.80 <= lon <= 122.05 and 30.55 <= lat <= 31.95


def geocode(address: str, key: str) -> dict:
    query = urllib.parse.urlencode({"key": key, "address": address, "city": "上海"})
    url = f"https://restapi.amap.com/v3/geocode/geo?{query}"
    with urllib.request.urlopen(url, timeout=20) as response:
        return json.loads(response.read().decode("utf-8"))


def main() -> None:
    key = os.environ.get("AMAP_API_KEY")
    if not key:
        raise SystemExit("Missing AMAP_API_KEY. Set it in the shell environment; never write it into this file or GitHub.")
    data = json.loads(INPUT.read_text(encoding="utf-8"))
    success = no_result = rejected = api_error = 0
    for venue in data["venues"]:
        address = venue.get("address_query_for_geocoding")
        if not address:
            continue
        try:
            result = geocode(address, key)
        except Exception as exc:  # keeps a per-venue failure without printing the secret
            venue["geocoding_status"] = "amap_request_failed"
            venue["geocoding_error"] = str(exc)
            api_error += 1
            continue
        records = result.get("geocodes") or []
        if result.get("status") != "1" or not records:
            venue["geocoding_status"] = "amap_no_result"
            venue["amap_response_info"] = result.get("info")
            no_result += 1
            continue
        location = records[0].get("location", "")
        try:
            lon_text, lat_text = location.split(",")
            lon, lat = float(lon_text), float(lat_text)
        except (TypeError, ValueError):
            venue["geocoding_status"] = "amap_invalid_coordinate"
            rejected += 1
            continue
        if not in_shanghai(lon, lat):
            venue["geocoding_status"] = "amap_coordinate_rejected_outside_shanghai_range"
            venue["amap_returned_coordinate"] = {"longitude": lon, "latitude": lat}
            rejected += 1
            continue
        venue["coordinate"] = {"longitude": lon, "latitude": lat}
        venue["coordinate_system"] = "GCJ-02"
        venue["coordinate_source"] = "高德地图地理编码服务（仅地址→坐标）"
        venue["geocoding_status"] = "amap_geocoded_needs_spot_check"
        success += 1
        time.sleep(0.12)
    data["geocoded_on"] = str(date.today())
    OUTPUT.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    REPORT.write_text(json.dumps({
        "success": success,
        "no_result": no_result,
        "rejected": rejected,
        "api_error": api_error,
        "coordinate_system": "GCJ-02",
        "required_follow_up": "对全部结果抽查；存在多个地址写法的场馆必须优先人工复核。",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"success": success, "no_result": no_result, "rejected": rejected, "api_error": api_error}, ensure_ascii=False))


if __name__ == "__main__":
    main()
