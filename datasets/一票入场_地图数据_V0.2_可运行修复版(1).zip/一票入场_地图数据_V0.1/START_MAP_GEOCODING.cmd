@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_map_geocoding.ps1"
pause
