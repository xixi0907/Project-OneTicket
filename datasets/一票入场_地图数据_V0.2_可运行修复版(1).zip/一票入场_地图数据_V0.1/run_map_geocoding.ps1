# This file intentionally contains ASCII characters only.
# It is compatible with Windows PowerShell 5.1 and does not require Python.

$ErrorActionPreference = 'Stop'
$dataDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$inputPath = Join-Path $dataDir 'map_venues.json'
$outputPath = Join-Path $dataDir 'map_venues_geocoded.json'
$reportPath = Join-Path $dataDir 'amap_geocoding_report.json'
$keyPointer = [IntPtr]::Zero

function Test-ShanghaiCoordinate {
    param([double]$Longitude, [double]$Latitude)
    return ($Longitude -ge 120.80 -and $Longitude -le 122.05 -and $Latitude -ge 30.55 -and $Latitude -le 31.95)
}

function Set-JsonFile {
    param($Object, [string]$Path)
    $json = $Object | ConvertTo-Json -Depth 100
    [System.IO.File]::WriteAllText($Path, $json, (New-Object System.Text.UTF8Encoding($false)))
}

try {
    $secureKey = Read-Host 'Paste your AMap Web Service Key, then press Enter' -AsSecureString
    $keyPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
    $apiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($keyPointer)
    if ([string]::IsNullOrWhiteSpace($apiKey)) {
        throw 'No key was entered.'
    }

    $data = Get-Content -LiteralPath $inputPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $success = 0
    $noResult = 0
    $rejected = 0
    $apiError = 0
    $total = @($data.venues | Where-Object { -not [string]::IsNullOrWhiteSpace($_.address_query_for_geocoding) }).Count
    $current = 0

    foreach ($venue in $data.venues) {
        $address = [string]$venue.address_query_for_geocoding
        if ([string]::IsNullOrWhiteSpace($address)) {
            continue
        }

        $current++
        Write-Host ("Processing {0}/{1}" -f $current, $total)
        try {
            $query = 'key=' + [uri]::EscapeDataString($apiKey) + '&address=' + [uri]::EscapeDataString($address) + '&city=' + [uri]::EscapeDataString('Shanghai')
            $response = Invoke-RestMethod -Uri ('https://restapi.amap.com/v3/geocode/geo?' + $query) -Method Get -TimeoutSec 30
        } catch {
            $venue.geocoding_status = 'amap_request_failed'
            $venue.geocoding_error = $_.Exception.Message
            $apiError++
            continue
        }

        $records = @($response.geocodes)
        if (([string]$response.status -ne '1') -or $records.Count -eq 0) {
            $venue.geocoding_status = 'amap_no_result'
            $venue | Add-Member -NotePropertyName amap_response_info -NotePropertyValue ([string]$response.info) -Force
            $noResult++
            continue
        }

        $parts = ([string]$records[0].location).Split(',')
        if ($parts.Count -ne 2) {
            $venue.geocoding_status = 'amap_invalid_coordinate'
            $rejected++
            continue
        }

        try {
            $longitude = [double]::Parse($parts[0], [System.Globalization.CultureInfo]::InvariantCulture)
            $latitude = [double]::Parse($parts[1], [System.Globalization.CultureInfo]::InvariantCulture)
        } catch {
            $venue.geocoding_status = 'amap_invalid_coordinate'
            $rejected++
            continue
        }

        if (-not (Test-ShanghaiCoordinate -Longitude $longitude -Latitude $latitude)) {
            $venue.geocoding_status = 'amap_coordinate_rejected_outside_shanghai_range'
            $venue | Add-Member -NotePropertyName amap_returned_coordinate -NotePropertyValue ([pscustomobject]@{ longitude = $longitude; latitude = $latitude }) -Force
            $rejected++
            continue
        }

        $venue.coordinate = [pscustomobject]@{ longitude = $longitude; latitude = $latitude }
        $venue.coordinate_system = 'GCJ-02'
        $venue.coordinate_source = 'AMap address geocoding only'
        $venue.geocoding_status = 'amap_geocoded_needs_spot_check'
        $success++
        Start-Sleep -Milliseconds 120
    }

    $data | Add-Member -NotePropertyName geocoded_on -NotePropertyValue ([DateTime]::UtcNow.ToString('yyyy-MM-dd')) -Force
    Set-JsonFile -Object $data -Path $outputPath
    $report = [pscustomobject]@{
        success = $success
        no_result = $noResult
        rejected = $rejected
        api_error = $apiError
        coordinate_system = 'GCJ-02'
        required_follow_up = 'Spot-check all results. Prioritize venues with multiple address variants.'
    }
    Set-JsonFile -Object $report -Path $reportPath
    Write-Host ''
    Write-Host 'Finished successfully.'
    Write-Host ("Success: {0}; no result: {1}; rejected: {2}; API error: {3}" -f $success, $noResult, $rejected, $apiError)
    Write-Host 'Created: map_venues_geocoded.json'
    Write-Host 'Created: amap_geocoding_report.json'
} catch {
    Write-Host ''
    Write-Host ('Stopped: ' + $_.Exception.Message)
    exit 1
} finally {
    if ($keyPointer -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($keyPointer)
    }
}
